function create(ctx, state, pids) {
    // Your custom logic here...
}

function render(ctx, state, pids) {
    // Your custom logic here...
}

function dispose(ctx, state, pids) {
    // Your custom logic here...
}