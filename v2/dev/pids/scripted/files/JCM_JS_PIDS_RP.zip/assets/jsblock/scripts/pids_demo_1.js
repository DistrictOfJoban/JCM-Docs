include(Resources.id("jsblock:scripts/pids_util.js")); // Built-in script shipped with JCM

function create(ctx, state, pids) {
}

function render(ctx, state, pids) {
    Texture.create("Background Text")
    .texture("jsblock:textures/demo_1_bg.png")
    .size(pids.width, pids.height)
    .draw(ctx);
    
    renderRouteColorStrip(ctx, pids);
    renderClock(ctx, pids);
    
    Text.create("Scheduled Text")
    .text("Scheduled")
    .pos(18, 18)
    .scale(0.65)
    .color(0xFFFFFF)
    .centerAlign()
    .draw(ctx);
    
    Text.create("Platform Text")
    .text("Platform")
    .pos(58, 18)
    .scale(0.65)
    .color(0xFFFFFF)
    .centerAlign()
    .draw(ctx);
    
    Text.create("Departs in Text")
    .text("Departs in")
    .pos(104, 21)
    .scale(0.8)
    .color(0xFFFFFF)
    .centerAlign()
    .draw(ctx);
    
    Text.create("Arrival Header Text")
    .text("Plat.   Depart   Destination")
    .pos(pids.width - 2, 44)
    .scale(0.54)
    .color(0xFFFFFF)
    .rightAlign()
    .draw(ctx);
    
    renderFirstArrivalInfo(ctx, pids);
    renderArrivalTable(ctx, pids);
    renderStoppingAt(ctx, pids);
}

function renderFirstArrivalInfo(ctx, pids) {
    let firstArrival = pids.arrivals().get(0);
    if(firstArrival == null) return;
    Text.create("Destination")
    .text(TextUtil.getNonCjkParts(firstArrival.destination()))
    .pos(36, 6)
    .size(74, 9)
    .scaleXY()
    .scale(0.85)
    .color(0xFFFFFF)
    .centerAlign()
    .draw(ctx);
    
    Text.create("Scheduled Arrival")
    .text(PIDSUtil.formatDateTime(new Date(firstArrival.arrivalTime())))
    .pos(18, 25)
    .scale(0.65)
    .color(0xFFFFFF)
    .centerAlign()
    .draw(ctx);
    
    Text.create("Platform Text")
    .text(firstArrival.platformName())
    .pos(58, 25)
    .scale(0.65)
    .color(0xFFFFFF)
    .centerAlign()
    .draw(ctx);
    
    let departInText = PIDSUtil.getETAText(firstArrival.departureTime(), "Now");
    Text.create("Departs in")
    .text(TextUtil.getNonCjkParts(departInText))
    .pos(104, 31)
    .scale(1.175)
    .color(0xFFFFFF)
    .centerAlign()
    .draw(ctx);
}

function renderRouteColorStrip(ctx, pids) {
    let firstArrival = pids.arrivals().get(0);
    if(firstArrival == null) return;
    
    Texture.create("Background")
    .texture("jsblock:textures/demo_1_rt.png")
    .color(firstArrival.routeColor())
    .size(pids.width, pids.height)
    .draw(ctx);
}

function renderClock(ctx, pids) {
    Text.create("Time is now Text")
    .text("Time is now:")
    .pos(pids.width - 26, 5.5)
    .scale(0.6)
    .color(0x08217F)
    .italic()
    .rightAlign()
    .draw(ctx);
    
    Text.create("Time")
    .text(PIDSUtil.formatDateTime(new Date()))
    .pos(pids.width - 4, 4)
    .scale(0.875)
    .rightAlign()
    .color(0x08217F)
    .draw(ctx);
}

function renderStoppingAt(ctx, pids) {
    let firstArrival = pids.arrivals().get(0);
    if(firstArrival == null) return;
    let rt = firstArrival.route();
    let platList = rt.getPlatforms();
    let ourIdx = rt.getPlatformIndex(firstArrival.platformId());
    
    Text.create("Stopping at Text")
    .text("Stopping at:")
    .pos(7, 36)
    .scale(0.65)
    .draw(ctx);

    for(let i = ourIdx; i < platList.size(); i++) {
        if(i >= ourIdx + 4) break; // Limit arrival to 4
        
        let heightOffset = (i - ourIdx) * 6.75;
        let stopStr = "";
        if(i == ourIdx) stopStr += "> ";
        
        stopStr += TextUtil.getNonCjkParts(platList[i].getStationName());
        Text.create("Stopping at station")
        .text(stopStr)
        .pos(7, 43 + heightOffset)
        .size(100, 6.75)
        .scaleXY()
        .scale(0.6)
        .draw(ctx);
    }    
}

function renderArrivalTable(ctx, pids) {
    for(let i = 0; i < 3; i++) {        
        let arrival = pids.arrivals().get(i+1); // Skip first arrival entry
        if(arrival == null) continue;
        let rowY = 53 + (i * 6);
        
        Text.create("Platform")
        .text(arrival.platformName())
        .pos(78, rowY)
        .scale(0.54)
        .color(0xFFFFFF)
        .centerAlign()
        .draw(ctx);
        
        Text.create("Depart Time")
        .text(PIDSUtil.formatDateTime(new Date(arrival.departureTime())))
        .pos(96, rowY)
        .scale(0.54)
        .color(0xFFFFFF)
        .centerAlign()
        .draw(ctx);
        
        Text.create("Destination")
        .text(TextUtil.getNonCjkParts(arrival.destination()))
        .pos(pids.width - 2, rowY)
        .scale(0.54)
        .size(48, 9)
        .scaleXY()
        .color(0xFFFFFF)
        .rightAlign()
        .draw(ctx);
    }
}

function dispose(ctx, state, pids) {
}