include(Resources.id("jsblock:scripts/pids_util.js")); // Built-in script shipped with JCM
const HEADER_HEIGHT = 13;

function create(ctx, state, pids) {
}

function render(ctx, state, pids) {
    Texture.create("Background")
    .texture("jsblock:textures/block/pids/rv_default.png")
    .size(pids.width, pids.height)
    .draw(ctx);
    
    // Arrivals
    for(let i = 0; i < pids.rows; i++) {
        let rowY = HEADER_HEIGHT + (i*16.75);
        let arrival = pids.arrivals().get(i);
        if(arrival == null) {
            continue;
        }
        
        Text.create("Destination Text")
        .text(TextUtil.cycleString(arrival.destination()))
        .scale(1.25)
        .pos(5, rowY)
        .draw(ctx);
        
        Text.create("ETA Text")
        .text(TextUtil.cycleString(PIDSUtil.getETAText(arrival.arrivalTime())))
        .scale(1.25)
        .rightAlign()
        .pos(pids.width - 8, rowY)
        .draw(ctx);
    }
}

function dispose(ctx, state, pids) {
}