function create(ctx, state, pids) {
    print("Hello World ^^");
}

function render(ctx, state, pids) {
    // Arrivals
    for(let i = 0; i < pids.rows; i++) {
        let arrival = pids.arrivals().get(i);
        if(arrival == null) {
            continue;
        }

        Text.create("Arrival destination")
        .text(TextUtil.cycleString(arrival.destination()))
        .scale(1.25)
        .pos(0, i*16.75)
        .color(0xFFFFFF)
        .draw(ctx);
    }
}

function dispose(ctx, state, pids) {
    print("Goodbye World ^^;");
}