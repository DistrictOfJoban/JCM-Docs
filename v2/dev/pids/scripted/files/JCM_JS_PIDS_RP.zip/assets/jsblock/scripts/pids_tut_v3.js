include(Resources.id("jsblock:scripts/pids_util.js")); // Built-in script shipped with JCM
const HEADER_HEIGHT = 13;

function create(ctx, state, pids) {
}

function render(ctx, state, pids) {
    Texture.create("Background")
    .texture("jsblock:textures/block/pids/rv_default.png")
    .size(pids.width, pids.height)
    .draw(ctx);
    
    // Top Bar
    // Draw weather icon
    let weatherImg;
    if(MinecraftClient.worldIsThundering()) {
        weatherImg = "jsblock:textures/block/pids/weather_thunder.png";
    } else if(MinecraftClient.worldIsRaining()) {
        weatherImg = "jsblock:textures/block/pids/weather_raining.png";
    } else {
        weatherImg = "jsblock:textures/block/pids/weather_sunny.png";
    }
    
    Texture.create("Weather Icon")
    .texture(weatherImg)
    .pos(5, 0)
    .size(10, 10)
    .draw(ctx);
    
    Text.create("Clock")
    .text(PIDSUtil.formatTime(MinecraftClient.worldDayTime(), true))
    .color(0xFFFFFF)
    .pos(pids.width - 5, 2)
    .scale(0.9)
    .rightAlign()
    .draw(ctx);
    
    
    // Arrivals
    for(let i = 0; i < pids.rows; i++) {
        let rowY = HEADER_HEIGHT + (i*16.75);
        let arrival = pids.arrivals().get(i);
        if(arrival == null) {
            continue;
        }

        Texture.create("LRT Circle White")
        .texture("mtr:textures/block/white.png")
        .pos(7.5, rowY+1.5)
        .size(18, 6)
        .draw(ctx);
        
        Texture.create("LRT Circle Colored")
        .texture("jsblock:textures/lrr.png")
        .color(arrival.routeColor())
        .pos(5, rowY-0.5)
        .size(23, 10)
        .draw(ctx);
        
        Text.create("LRT Number Text")
        .text(arrival.routeNumber())
        .scale(0.55)
        .centerAlign()
        .pos(16.5, rowY+2.75)
        .draw(ctx);
        
        Text.create("Destination Text")
        .text(TextUtil.cycleString(arrival.destination()))
        .scale(1.25)
        .pos(30, rowY)
        .draw(ctx);
        
        Texture.create("Platform Circle")
        .texture("jsblock:textures/block/pids/plat_circle.png")
        .pos(79, rowY - 1)
        .size(10.5, 10.5)
        .color(0xD2A808) // Hong Kong LRT Network Color
        .draw(ctx);
        
        Text.create("Platform Circle Text")
        .text(arrival.platformName())
        .pos(84, rowY + 1)
        .scale(0.9)
        .centerAlign()
        .color(0xFFFFFF)
        .draw(ctx);
        
        Text.create("ETA Text")
        .text(TextUtil.cycleString(PIDSUtil.getETAText(arrival.arrivalTime())))
        .scale(1.25)
        .rightAlign()
        .pos(pids.width - 8, rowY)
        .draw(ctx);
    }
}

function dispose(ctx, state, pids) {
}